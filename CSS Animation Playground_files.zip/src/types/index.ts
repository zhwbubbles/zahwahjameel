export  interface AnimationPreset {
  id: string;
  name: string;
  code: string;
  description: string;
}

export interface AppState {
  code: string;
  selectedPreset: string | null;
  setCode: (code: string) => void;
  setSelectedPreset: (id: string | null) => void;
}
 