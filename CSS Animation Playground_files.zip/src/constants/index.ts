import  { AnimationPreset } from '../types';

export const DEFAULT_CODE = `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  animation: bounce 1s infinite;
}

@keyframes bounce {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-20px);
  }
}`.trim();

export const ANIMATION_PRESETS: AnimationPreset[] = [
  {
    id: 'bounce',
    name: 'Bounce',
    description: 'A simple bouncing animation',
    code: DEFAULT_CODE,
  },
  {
    id: 'pulse',
    name: 'Pulse',
    description: 'Pulsating scale effect',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  border-radius: 50%;
  animation: pulse 1.5s infinite;
}

@keyframes pulse {
  0% {
    transform: scale(1);
    box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7);
  }
  70% {
    transform: scale(1.1);
    box-shadow: 0 0 0 15px rgba(59, 130, 246, 0);
  }
  100% {
    transform: scale(1);
    box-shadow: 0 0 0 0 rgba(59, 130, 246, 0);
  }
}`.trim(),
  },
  {
    id: 'shake',
    name: 'Shake',
    description: 'Energetic shaking motion',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  animation: shake 0.5s infinite;
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-10px) rotate(-5deg); }
  75% { transform: translateX(10px) rotate(5deg); }
}`.trim(),
  },
  {
    id: 'morph',
    name: 'Morph',
    description: 'Shape morphing effect',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  animation: morph 3s infinite;
}

@keyframes morph {
  0% { border-radius: 0; }
  25% { border-radius: 50% 0 0 0; }
  50% { border-radius: 50% 50% 0 0; }
  75% { border-radius: 50% 50% 50% 0; }
  100% { border-radius: 50%; }
}`.trim(),
  },
  {
    id: 'ripple',
    name: 'Ripple',
    description: 'Expanding ripple effect',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  border-radius: 50%;
  position: relative;
}

.preview-element::before,
.preview-element::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border-radius: 50%;
  animation: ripple 2s infinite;
  border: 2px solid #3b82f6;
}

.preview-element::after {
  animation-delay: 1s;
}

@keyframes ripple {
  0% {
    transform: scale(1);
    opacity: 1;
  }
  100% {
    transform: scale(2);
    opacity: 0;
  }
}`.trim(),
  },
  {
    id: 'swing',
    name: 'Swing',
    description: 'Pendulum-like swing motion',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  transform-origin: top center;
  animation: swing 2s infinite ease-in-out;
}

@keyframes swing {
  0%, 100% { transform: rotate(15deg); }
  50% { transform: rotate(-15deg); }
}`.trim(),
  },
  {
    id: 'glitch',
    name: 'Glitch',
    description: 'Digital glitch effect',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  position: relative;
  animation: glitch 0.5s infinite;
}

@keyframes glitch {
  0% {
    transform: translate(0);
    filter: hue-rotate(0deg);
  }
  25% {
    transform: translate(-2px, 2px);
    filter: hue-rotate(90deg);
  }
  50% {
    transform: translate(2px, -2px);
    filter: hue-rotate(180deg);
  }
  75% {
    transform: translate(-2px, -2px);
    filter: hue-rotate(270deg);
  }
  100% {
    transform: translate(0);
    filter: hue-rotate(360deg);
  }
}`.trim(),
  },
  {
    id: 'spotlight',
    name: 'Spotlight',
    description: 'Moving spotlight effect',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: radial-gradient(circle at 50% 50%, #3b82f6, #1e40af);
  animation: spotlight 4s infinite;
}

@keyframes spotlight {
  0% { background: radial-gradient(circle at 50% 50%, #3b82f6, #1e40af); }
  25% { background: radial-gradient(circle at 0% 0%, #3b82f6, #1e40af); }
  50% { background: radial-gradient(circle at 100% 0%, #3b82f6, #1e40af); }
  75% { background: radial-gradient(circle at 100% 100%, #3b82f6, #1e40af); }
  100% { background: radial-gradient(circle at 50% 50%, #3b82f6, #1e40af); }
}`.trim(),
  },
  {
    id: 'elastic',
    name: 'Elastic',
    description: 'Stretchy elastic motion',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  animation: elastic 2s infinite cubic-bezier(0.68, -0.55, 0.265, 1.55);
}

@keyframes elastic {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.3, 0.7); }
  65% { transform: scale(0.8, 1.2); }
  80% { transform: scale(1.2, 0.9); }
  90% { transform: scale(0.95, 1.05); }
}`.trim(),
  },
  {
    id: 'heartbeat',
    name: 'Heartbeat',
    description: 'Rhythmic heartbeat effect',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #ef4444;
  border-radius: 50%;
  animation: heartbeat 1.5s infinite;
}

@keyframes heartbeat {
  0% { transform: scale(1); }
  14% { transform: scale(1.3); }
  28% { transform: scale(1); }
  42% { transform: scale(1.3); }
  70% { transform: scale(1); }
}`.trim(),
  },
  {
    id: 'rainbow',
    name: 'Rainbow',
    description: 'Cycling rainbow colors',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: linear-gradient(45deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #8b00ff);
  background-size: 700% 700%;
  animation: rainbow 8s linear infinite;
}

@keyframes rainbow {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}`.trim(),
  },
  {
    id: 'typewriter',
    name: 'Typewriter',
    description: 'Typing cursor effect',
    code: `
.preview-element {
  width: 4px;
  height: 100px;
  background: #3b82f6;
  animation: typewriter 1s infinite;
}

@keyframes typewriter {
  0%, 100% { opacity: 1; }
  50% { opacity: 0; }
}`.trim(),
  },
  // New presets
  {
    id: 'flip3d',
    name: '3D Flip',
    description: 'Continuous 3D rotation effect',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  animation: flip3d 3s infinite linear;
  transform-style: preserve-3d;
}

@keyframes flip3d {
  0% { transform: perspective(400px) rotateY(0); }
  100% { transform: perspective(400px) rotateY(360deg); }
}`.trim(),
  },
  {
    id: 'explosion',
    name: 'Explosion',
    description: 'Particle explosion animation',
    code: `
.preview-element {
  width: 20px;
  height: 20px;
  background: #3b82f6;
  position: relative;
}

.preview-element::before,
.preview-element::after {
  content: '';
  position: absolute;
  width: 100%;
  height: 100%;
  background: inherit;
  animation: explode 1.5s infinite;
}

.preview-element::after {
  animation-delay: 0.25s;
}

@keyframes explode {
  0% {
    transform: translate(0, 0) scale(1);
    opacity: 1;
  }
  100% {
    transform: translate(var(--x, 50px), var(--y, -50px)) scale(0);
    opacity: 0;
  }
}

.preview-element::before { --x: -50px; --y: 50px; }`.trim(),
  },
  {
    id: 'liquidMorph',
    name: 'Liquid Morph',
    description: 'Smooth liquid-like transformation',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  animation: liquidMorph 4s ease-in-out infinite;
  border-radius: 60% 40% 30% 70% / 60% 30% 70% 40%;
}

@keyframes liquidMorph {
  0% { border-radius: 60% 40% 30% 70% / 60% 30% 70% 40%; }
  50% { border-radius: 30% 60% 70% 40% / 50% 60% 30% 60%; }
  100% { border-radius: 60% 40% 30% 70% / 60% 30% 70% 40%; }
}`.trim(),
  },
  {
    id: 'neonPulse',
    name: 'Neon Pulse',
    description: 'Glowing neon effect',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  animation: neonPulse 2s infinite;
  box-shadow: 0 0 10px #3b82f6,
              0 0 20px #3b82f6,
              0 0 30px #3b82f6,
              0 0 40px #3b82f6;
}

@keyframes neonPulse {
  0% { filter: brightness(1); }
  50% { filter: brightness(1.5); }
  100% { filter: brightness(1); }
}`.trim(),
  },
  {
    id: 'magneticPull',
    name: 'Magnetic Pull',
    description: 'Magnetic attraction animation',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  animation: magneticPull 2s infinite;
}

@keyframes magneticPull {
  0%, 100% { transform: scale(1) translate(0, 0); }
  25% { transform: scale(0.8) translate(20px, 20px); }
  50% { transform: scale(1.2) translate(0, 0); }
  75% { transform: scale(0.8) translate(-20px, -20px); }
}`.trim(),
  },
  {
    id: 'origami',
    name: 'Origami',
    description: 'Paper folding animation',
    code: `
.preview-element {
  width: 100px;
  height: 100px;
  background: #3b82f6;
  animation: origami 3s infinite;
  transform-origin: top left;
}

@keyframes origami {
  0% { transform: rotate3d(0, 0, 0, 0deg); }
  25% { transform: rotate3d(1, 0, 0, -90deg); }
  50% { transform: rotate3d(1, 0, 0, -90deg) rotate3d(0, 1, 0, -90deg); }
  75% { transform: rotate3d(1, 1, 0, -180deg); }
  100% { transform: rotate3d(0, 0, 0, 0deg); }
}`.trim(),
  }
];
 