import  { CodeEditor } from './components/CodeEditor';
import { Header } from './components/Header';
import { Presets } from './components/Presets';
import { Preview } from './components/Preview';

function App() {
  return (
    <div className="flex flex-col h-screen bg-slate-950">
      <Header />
      
      <main className="flex-1 grid grid-cols-[250px_1fr_1fr] gap-4 p-4 overflow-hidden">
        <div className="bg-slate-900 rounded-lg p-4 overflow-y-auto">
          <Presets />
        </div>
        
        <div className="bg-slate-900 rounded-lg overflow-hidden">
          <CodeEditor />
        </div>
        
        <div className="overflow-hidden">
          <Preview />
        </div>
      </main>
    </div>
  );
}

export default App;
 