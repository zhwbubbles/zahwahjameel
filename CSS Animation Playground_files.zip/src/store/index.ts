import  { create } from 'zustand';
import { AppState } from '../types';
import { DEFAULT_CODE } from '../constants';

export const useStore = create<AppState>((set) => ({
  code: DEFAULT_CODE,
  selectedPreset: null,
  setCode: (code) => set({ code }),
  setSelectedPreset: (id) => set({ selectedPreset: id }),
}));
 