import  { Copy, GithubIcon } from 'lucide-react';
import { useStore } from '../store';

export const Header = () => {
  const { code } = useStore();

  const copyCode = () => {
    // Create a temporary textarea element
    const textarea = document.createElement('textarea');
    textarea.value = code;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    
    try {
      // Select and copy the text
      textarea.select();
      document.execCommand('copy');
      alert('Code copied to clipboard!');
    } catch (err) {
      console.error('Failed to copy code:', err);
      alert('Failed to copy code. Please try selecting and copying manually.');
    } finally {
      // Clean up
      document.body.removeChild(textarea);
    }
  };

  return (
    <header className="flex items-center justify-between px-6 py-4 bg-slate-900 border-b border-slate-800">
      <div className="flex items-center space-x-2">
        <div className="text-xl font-bold text-white">CSS Animation Playground</div>
        <div className="text-sm text-slate-400">v1.0.0</div>
      </div>
      
      <div className="flex items-center space-x-4">
        <button
          onClick={copyCode}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Copy size={16} />
          <span>Copy CSS</span>
        </button>
        
        <a
          href="https://github.com"
          target="_blank"
          rel="noopener noreferrer"
          className="text-slate-400 hover:text-white transition-colors"
        >
          <GithubIcon size={20} />
        </a>
      </div>
    </header>
  );
};
 