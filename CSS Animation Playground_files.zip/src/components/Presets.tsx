import  { ANIMATION_PRESETS } from '../constants';
import { useStore } from '../store';

export const Presets = () => {
  const { setCode, selectedPreset, setSelectedPreset } = useStore();

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold text-white">Animation Presets</h2>
      <div className="space-y-2">
        {ANIMATION_PRESETS.map((preset) => (
          <button
            key={preset.id}
            onClick={() => {
              setCode(preset.code);
              setSelectedPreset(preset.id);
            }}
            className={`w-full p-3 rounded-lg text-left transition-colors ${
              selectedPreset === preset.id
                ? 'bg-blue-600 text-white'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <div className="font-medium">{preset.name}</div>
            <div className="text-sm opacity-80">{preset.description}</div>
          </button>
        ))}
      </div>
    </div>
  );
};
 