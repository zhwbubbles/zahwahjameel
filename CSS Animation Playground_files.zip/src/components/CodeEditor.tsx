import  CodeMirror from '@uiw/react-codemirror';
import { css } from '@codemirror/lang-css';
import { vscodeDark } from '@uiw/codemirror-theme-vscode';
import { useStore } from '../store';

export const CodeEditor = () => {
  const { code, setCode } = useStore();

  return (
    <div className="h-full w-full">
      <CodeMirror
        value={code}
        height="100%"
        theme={vscodeDark}
        extensions={[css()]}
        onChange={(value) => setCode(value)}
        className="h-full text-sm"
      />
    </div>
  );
};
 