import  { useEffect, useRef, useState } from 'react';
import { useStore } from '../store';

export const Preview = () => {
  const { code } = useStore();
  const [styleId] = useState(`style-${Math.random().toString(36).substr(2, 9)}`);
  const initialized = useRef(false);

  useEffect(() => {
    if (!initialized.current) {
      const styleElement = document.createElement('style');
      styleElement.id = styleId;
      document.head.appendChild(styleElement);
      initialized.current = true;
    }

    const styleElement = document.getElementById(styleId);
    if (styleElement) {
      styleElement.textContent = code;
    }

    // Cleanup only when component unmounts
    return () => {
      if (initialized.current) {
        const styleElement = document.getElementById(styleId);
        if (styleElement && styleElement.parentNode) {
          styleElement.parentNode.removeChild(styleElement);
          initialized.current = false;
        }
      }
    };
  }, [code, styleId]);

  return (
    <div className="h-full w-full bg-slate-900 rounded-lg p-8 flex items-center justify-center">
      <div className="flex-1 h-full flex items-center justify-center bg-slate-800/50 rounded-lg backdrop-blur-sm relative overflow-hidden">
        <div className="preview-element" />
      </div>
    </div>
  );
};
 